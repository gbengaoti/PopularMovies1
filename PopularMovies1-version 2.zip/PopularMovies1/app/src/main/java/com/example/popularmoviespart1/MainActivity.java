package com.example.popularmoviespart1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.popularmoviespart1.model.Movie;
import com.example.popularmoviespart1.utilities.JsonUtils;
import com.example.popularmoviespart1.utilities.NetworkUtils;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MovieAdapter.MovieAdapterOnClickHandler, OnTaskCompleted {

    private RecyclerView mMovieRecyclerView;
    private TextView mErrorTextView;
    private MovieAdapter mMovieAdapter;
    private final String choiceKey = "CHOICE";
    final String POPULAR = "popular";
    final String RATING = "rated";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMovieRecyclerView = findViewById(R.id.my_recyler_view);
        mErrorTextView = findViewById(R.id.error_text_view);

        mMovieRecyclerView.setHasFixedSize(true);

        int NUMBER_OF_COLUMNS = 2;
        RecyclerView.LayoutManager layoutManager = (new GridLayoutManager(this, NUMBER_OF_COLUMNS));
        mMovieRecyclerView.setLayoutManager(layoutManager);

        mMovieAdapter = new MovieAdapter(this);

        /* Setting the adapter attaches it to the RecyclerView in our layout. */
        mMovieRecyclerView.setAdapter(mMovieAdapter);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPreferences",
                MODE_PRIVATE);

        String DEFAULT = "default";
        String choice = sharedPreferences.getString(choiceKey, DEFAULT);


        loadMovieData(choice);

    }

    private void showError(){
        mErrorTextView.setVisibility(View.VISIBLE);
        mMovieRecyclerView.setVisibility(View.INVISIBLE);

    }

    private void showRecyclerView(){
        mMovieRecyclerView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(Movie currentMovie) {
        Context context = this;
        Class destinationClass = DetailActivity.class;
        Intent intentToStartDetailActivity = new Intent(context, destinationClass);
        intentToStartDetailActivity.putExtra(Intent.EXTRA_TEXT, currentMovie);
        startActivity(intentToStartDetailActivity);
    }

    @Override
    public void onTaskCompleted(Movie[] movies) {
        if (movies != null){
            showRecyclerView();
            mMovieAdapter.setMovieData(movies);
        }else {
            showError();
        }
    }


    private static class FetchMovieTaskM extends AsyncTask<String, Void, Movie[]>{

        private WeakReference<MainActivity> activityReference;

        // only retain a weak reference to the activity
        FetchMovieTaskM(MainActivity context) {
            activityReference = new WeakReference<>(context);
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity activity = activityReference.get();
            if (activity == null || activity.isFinishing()) return;
            ProgressBar loadingIndicator = activity.findViewById(R.id.pb_loading_indicator);
            loadingIndicator.setVisibility(View.VISIBLE);
        }

        /**
         * Override this method to perform a computation on a background thread. The
         * specified parameters are the parameters passed to {@link #execute}
         * by the caller of this task.
         * <p>
         * This will normally run on a background thread. But to better
         * support testing frameworks, it is recommended that this also tolerates
         * direct execution on the foreground thread, as part of the {@link #execute} call.
         * <p>
         * This method can call {@link #publishProgress} to publish updates
         * on the UI thread.
         *
         * @param sort_param The parameters of the task.
         * @return A result, defined by the subclass of this task.
         * @see #onPreExecute()
         * @see #onPostExecute
         * @see #publishProgress
         */
        @Override
        protected Movie[] doInBackground(String... sort_param) {
            final String POPULAR = "popular";
            final String RATING = "rated";
            final String DEFAULT = "default";
            URL url = null;
            List<Movie> movieList = null;
            switch (sort_param[0]) {
                case POPULAR:
                    //load popular movies
                    url = NetworkUtils.buildPopularUrl();
                    break;
                case RATING:
                    url = NetworkUtils.buildRatedUrl();
                    break;
                case DEFAULT:
                    url = NetworkUtils.buildDefaultUrl();
                    break;
            }

            try {
                assert url != null;
                String jsonMovieResponse = NetworkUtils.getResponseFromHttpUrl(url);
                if (jsonMovieResponse != null){
                    movieList = JsonUtils.parseMovieJson(jsonMovieResponse);
                }
                if (movieList == null){
                    return null;
                }else{
                    return movieList.toArray(new Movie[0]);
                }
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }

        }

        @Override
        protected void onPostExecute(Movie[] movies) {
            MainActivity activity = activityReference.get();
            if (activity == null || activity.isFinishing()) return;
            ProgressBar loadingIndicator = activity.findViewById(R.id.pb_loading_indicator);
            loadingIndicator.setVisibility(View.INVISIBLE);

            activityReference.get().onTaskCompleted(movies);

        }
    }

    private void loadMovieData(String option){
        showRecyclerView();
        new FetchMovieTaskM(this).execute(option);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.selector_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPreferences",
                MODE_PRIVATE);
        SharedPreferences.Editor myEdit
                = sharedPreferences.edit();
        String mCurrentChoice;
        if (id == R.id.action_sort_popular) {
            mCurrentChoice = POPULAR;
            myEdit.putString(choiceKey, mCurrentChoice);
            myEdit.apply();
            loadMovieData(POPULAR);
            return true;
        }

        if(id == R.id.action_sort_rating){
            mCurrentChoice = RATING;
            myEdit.putString(choiceKey, mCurrentChoice);
            myEdit.apply();
            loadMovieData(RATING);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
