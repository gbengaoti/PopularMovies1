package com.example.popularmoviespart1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.popularmoviespart1.databinding.ActivityDetailBinding;
import com.example.popularmoviespart1.model.Movie;
import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

    private static final int WIDTH = 500;
    private static final int HEIGHT = 500;

    private static final String RATING_TOTAL = "/10";

    private static final String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";

    private TextView mMovieTitleView;
    private TextView mUserRatingView;
    private TextView mReleaseDateView;
    private TextView mSynopsisView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        com.example.popularmoviespart1.databinding.ActivityDetailBinding binding = ActivityDetailBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        mMovieTitleView = binding.movieTitle;
        ImageView mImageView = binding.imageBox;
        mUserRatingView = binding.userRating;
        mReleaseDateView = binding.releaseDate;;
        mSynopsisView = binding.synopsis;

        Intent intent = getIntent();
        if (intent == null) {
           closeOnError();
        }else{
            Movie currentMovie = intent.getParcelableExtra(Intent.EXTRA_TEXT);
            assert currentMovie != null;
            populateDetailUI(currentMovie);
            String getPath = currentMovie.getPosterPath();
            String fullPath = IMAGE_BASE_URL + getPath;
            Picasso.get()
                    .load(fullPath)
                    .placeholder(R.mipmap.placeholder_image)
                    .error(R.mipmap.placeholder_error_image)
                    .resize(WIDTH, HEIGHT)
                    .into(mImageView);

        }
    }

    private void populateDetailUI(Movie movieDetail) {
        mMovieTitleView.setText(movieDetail.getTitle());
        mSynopsisView.setText(movieDetail.getSynopsis());
        mReleaseDateView.setText(movieDetail.getReleaseDate().substring(0,4));
        mUserRatingView.setText(String.format("%s%s", movieDetail.getUserRating(), RATING_TOTAL));
    }

    private void closeOnError(){
        finish();
        Toast.makeText(this, R.string.detail_error_message, Toast.LENGTH_SHORT).show();
    }
}
