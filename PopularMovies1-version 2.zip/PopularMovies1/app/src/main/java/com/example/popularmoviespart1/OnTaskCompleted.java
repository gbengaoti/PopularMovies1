package com.example.popularmoviespart1;

import com.example.popularmoviespart1.model.Movie;

public interface OnTaskCompleted {
    void onTaskCompleted(Movie[] movies);
}

